import { defaultTheme } from "react-admin";

export const theme = {
    ...defaultTheme,
    typography: {
        fontSize: 24
    }
};